"""
Google OAuth for Streamlit — works with any deployment (Coolify, Railway, etc.)
Set these env vars in Coolify:
  GOOGLE_CLIENT_ID
  GOOGLE_CLIENT_SECRET
  REDIRECT_URI  (e.g. https://yourdomain.com/oauth2callback)
  ALLOWED_EMAILS  (comma-separated, optional — lock to your Gmail)
"""
import streamlit as st
import os
import requests
from urllib.parse import urlencode, urlparse, parse_qs
import hashlib, secrets, json

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"

def _secret(key: str, default: str = "") -> str:
    """Read from st.secrets first, then os.environ — works on both Streamlit Cloud and Coolify."""
    try:
        return st.secrets.get(key, os.environ.get(key, default))
    except Exception:
        return os.environ.get(key, default)

def init_auth():
    if "oauth_state" not in st.session_state:
        st.session_state.oauth_state = None
    if "user" not in st.session_state:
        st.session_state.user = None

    # Handle OAuth callback via query params
    params = st.query_params
    if "code" in params and "state" in params:
        _handle_callback(params["code"], params["state"])

def _get_redirect_uri():
    return _secret("REDIRECT_URI", "http://localhost:8501")

def _build_auth_url():
    state = secrets.token_urlsafe(32)
    st.session_state.oauth_state = state
    params = {
        "client_id": _secret("GOOGLE_CLIENT_ID"),
        "redirect_uri": _get_redirect_uri(),
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "offline",
        "prompt": "select_account",
    }
    return f"{GOOGLE_AUTH_URL}?{urlencode(params)}"

def _handle_callback(code: str, state: str):
    if state != st.session_state.get("oauth_state"):
        st.error("Invalid OAuth state. Please try again.")
        st.stop()
    try:
        token_resp = requests.post(GOOGLE_TOKEN_URL, data={
            "code": code,
            "client_id": _secret("GOOGLE_CLIENT_ID"),
            "client_secret": _secret("GOOGLE_CLIENT_SECRET"),
            "redirect_uri": _get_redirect_uri(),
            "grant_type": "authorization_code",
        }, timeout=10)
        token_data = token_resp.json()
        access_token = token_data.get("access_token")
        if not access_token:
            st.error(f"Token exchange failed: {token_data}")
            st.stop()
        user_resp = requests.get(GOOGLE_USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"}, timeout=10)
        user = user_resp.json()

        # Optional: restrict to allowed emails
        allowed = _secret("ALLOWED_EMAILS", "")
        if allowed:
            allowed_list = [e.strip() for e in allowed.split(",")]
            if user.get("email") not in allowed_list:
                st.error(f"❌ Access denied for {user.get('email')}. Contact Adam.")
                st.stop()

        st.session_state.user = user
        st.query_params.clear()
        st.rerun()
    except Exception as e:
        st.error(f"Auth error: {e}")

def is_authenticated() -> bool:
    return st.session_state.get("user") is not None

def get_user() -> dict:
    return st.session_state.get("user", {})

def render_login_page():
    st.markdown("""
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
    min-height:80vh;gap:24px;">
        <div style="font-size:72px;">⚡</div>
        <h1 style="font-family:'Space Grotesk',sans-serif;font-size:2.8rem;margin:0;
        background:linear-gradient(135deg,#ff4d4d,#ff8c00);
        -webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            Adam's System Builder
        </h1>
        <p style="color:#888;font-size:1.1rem;margin:0;">
            Agentic AI webapp factory — n8n · Coolify · Supabase · Claude Code
        </p>
    </div>
    """, unsafe_allow_html=True)

    client_id = _secret("GOOGLE_CLIENT_ID")
    if not client_id:
        st.warning("⚙️ GOOGLE_CLIENT_ID not set. Add it in Coolify → Environment Variables.")
        st.code("GOOGLE_CLIENT_ID=your-id-here.apps.googleusercontent.com", language="bash")
        return

    auth_url = _build_auth_url()
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        st.markdown(f"""
        <a href="{auth_url}" style="display:block;text-align:center;background:#fff;
        color:#333;padding:14px 28px;border-radius:8px;font-weight:600;
        text-decoration:none;border:2px solid #ddd;font-size:1rem;
        box-shadow:0 2px 8px rgba(0,0,0,0.15);">
            <img src="https://www.google.com/favicon.ico" style="width:18px;vertical-align:middle;margin-right:8px;"/>
            Sign in with Google
        </a>
        """, unsafe_allow_html=True)
